version = "1.1"
moddir = "/usr/share/rubber"
